public class LinkedList {
	Node first, last;
	private int count;

	public LinkedList() {

	}

	/* Add in the beginning of linked list* */
	public void addFirst(Book element) {
		Node temp = new Node(element);
		temp.next = first;
		first = temp;

		if (count == 0) {
			last = first;
		}

		count++;

	}

	/* Add in the end of linked list* */
	public void addLast(Book element) {
		Node temp = new Node(element);
		if (count == 0) {
			first = last = temp;
		} else {
			last.next = temp;
			last = temp;

		}
		count++;
	}

	public boolean removeFirst() {
		if (count == 0) {
			return false;
		}

		else if (first == last) {
			first = last = null;
		}

		else
			first = first.next;

		count--;
		return true;
	}

	/** remove the last node in the linked list */
	public boolean removeLast() {
		if (count == 0) {
			return false;
		}

		else if (first == last) {
			first = last = null;
		} else {
			Node temp = new Node();
			temp = first;
			for (int i = 0; i < count - 1; i++) {
				temp = temp.next;
			}
			temp.next = null;

		}
		count--;
		return true;

	}

	/** remove the node in the specific index in linked list */
	public boolean remove(int index) {
		if (count == 0) {
			return false;
		} else {
			Node temp = new Node();
			Node temp2 = new Node();
			temp = first;
			for (int i = 0; i < index - 1; i++) {
				temp = temp.next;
			}
			temp2 = temp.next;
			temp = temp2.next;
			temp2 = null;
		}
		count--;
		return true;

	}

	/* return the size of lisnked list* */
	public int getSize() {
		return count;

	}

	/* remove specific node in the list * */
	public boolean remove(Node x) {
		Node previous = first;
		Node current;
		if (first != null) {
			if (x.element.getTitle().equals(first.element.getTitle())
					&& x.element.getAuthor().equals(first.element.getAuthor())
					&& x.element.getEdition()
							.equals(first.element.getEdition())
					&& x.element.getPublisher().equals(
							first.element.getPublisher())) {
				return (removeFirst());
			}
		} else
			return false;

		current = first.next;
		for (int i = 0; i < count - 1; i++) {
			if (x.element.getTitle().equals(current.element.getTitle())
					&& x.element.getAuthor()
							.equals(current.element.getAuthor())
					&& x.element.getEdition().equals(
							current.element.getEdition())
					&& x.element.getPublisher().equals(
							current.element.getPublisher())) {
				previous.next = current.next;
				count--;
				return true;
			} else {
				previous = current;
				current = current.next;

			}
		}
		return false;

	}

	/* print the list* */
	public void printList() {
		Node temp = first;

		for (int i = 0; i < count; i++) {
			System.out.println(temp.element);
			temp = temp.next;
		}
	}
}
