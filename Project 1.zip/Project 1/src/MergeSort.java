public class MergeSort {

	/** mergeSort method to cut array to tow array */
	public static Book[] mergeSort(Book[] list) {
		if (list.length <= 1) {
			return list;
		}

		Book[] first = new Book[list.length / 2];
		Book[] second = new Book[list.length - first.length];

		System.arraycopy(list, 0, first, 0, first.length);
		System.arraycopy(list, first.length, second, 0, second.length);

		mergeSort(first);
		mergeSort(second);

		merge(first, second, list);
		return list;

	}

	/** merge method to sort two array and merge it */
	public static void merge(Book[] a, Book[] b, Book[] list) {
		int iFirst = 0;
		int iSecond = 0;
		int j = 0;

		while (iFirst < a.length && iSecond < b.length) {
			if (a[iFirst].getTitle().compareTo(b[iSecond].getTitle()) < 0) {
				list[j] = a[iFirst];
				iFirst++;
			} else {
				list[j] = b[iSecond];
				iSecond++;
			}
			j++;
		}
		System.arraycopy(a, iFirst, list, j, a.length - iFirst);
		System.arraycopy(b, iSecond, list, j, b.length - iSecond);
	}

}
