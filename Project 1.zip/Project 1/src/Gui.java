import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.Scanner;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.TitledBorder;

public class Gui {
	/** create a new object of linkedlist (Book) */
	static LinkedList book_list = new LinkedList();
	static File file;

	/* no argument constructor* */
	public Gui() {

		/** create new frame */

		JFrame frame = new JFrame("library shop ");
		frame.setSize(500, 250);
		frame.setLocation(200, 100);
		frame.setLayout(new BorderLayout());
		frame.setResizable(false);

		/** create new button */
		final JButton purchase = new JButton("add books to the stock");
		purchase.setEnabled(false);
		final JButton sale = new JButton("sale");
		sale.setEnabled(false);
		final JButton display = new JButton("Display Stock");
		display.setEnabled(false);
		final JButton Search = new JButton("Search");
		Search.setEnabled(false);
		final JButton report = new JButton("report");
		report.setEnabled(false);
		final JButton exit = new JButton("Exit");

		JPanel p0 = new JPanel();
		p0.setLayout(new BorderLayout());
		p0.setBorder(new TitledBorder("Select File"));
		final JTextField text = new JTextField("No File Uploaded");
		text.setEnabled(false);
		JButton browse = new JButton("Load Books");
		/** add text filed and browse button to panel */
		p0.add(text);
		p0.add(browse, BorderLayout.EAST);
		frame.add(p0, BorderLayout.NORTH);

		JPanel p4 = new JPanel();
		p4.setLayout(new BorderLayout());

		JPanel p3 = new JPanel();

		ImageIcon image = new ImageIcon("java.png");
		JButton b = new JButton(image);

		p3.add(b);
		p4.add(p3, BorderLayout.EAST);

		JPanel p1 = new JPanel();
		p1.setLayout(new GridLayout(5, 1));
		p1.setBorder(new TitledBorder("Setings"));

		p1.add(purchase);
		p1.add(sale);
		p1.add(display);
		p1.add(Search);
		p1.add(report);

		p4.add(p1, BorderLayout.CENTER);

		final JPanel p2 = new JPanel();
		p2.setLayout(new FlowLayout());
		p2.add(exit);

		frame.add(p2, BorderLayout.SOUTH);
		frame.add(p4, BorderLayout.CENTER);

		/** set an action listener to exit button */
		exit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);

			}
		});

		/** set an action listener to about button */
		b.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,
						"This program is a library system with many functions",
						" About!", JOptionPane.INFORMATION_MESSAGE);

			}
		});
		/** set an action listener to browse button */
		browse.addActionListener(new ActionListener() {

			private Scanner input;

			@Override
			public void actionPerformed(ActionEvent e) {

				file = null;
				/** create a new File Chooser */
				JFileChooser choose = new JFileChooser();
				if (choose.showOpenDialog(choose) == JFileChooser.APPROVE_OPTION) {
					file = choose.getSelectedFile();
				}
				Scanner reader = null;

				if (file != null) {
					try {
						text.setText(file.getPath());
						purchase.setEnabled(true);
						sale.setEnabled(true);
						display.setEnabled(true);
						Search.setEnabled(true);
						report.setEnabled(true);

						reader = new Scanner(file);
					} catch (FileNotFoundException ex) {
						ex.printStackTrace();
					}

					/**
					 * open file and read all String from it then add the String
					 * to the list_b
					 */
					try {
						input = new Scanner(file);
						if (file.canRead() == false) {
							JOptionPane.showMessageDialog(null,
									"The file cant't reed");
						} else {
							while (input.hasNextLine()) {
								String s = input.nextLine();
								String[] list = s.split(":");
								try {
									int q = Integer.parseInt(list[5]);
									Book book = new Book(list[0], list[1],
											list[2], list[3], list[4], q);
									book_list.addLast(book);
								} catch (NumberFormatException nfe) {
									JOptionPane
											.showMessageDialog(
													null,
													"Enter a numerical number in the quantity Field, there is a book has a non numerical number in the quantity");
								}

							}
						}

					}
					/** not found Exception if the file not found */
					catch (FileNotFoundException e1) {
						JOptionPane.showMessageDialog(null, "File not found");
						e1.printStackTrace();
					}
				}
			}

		});

		/** set an action listener to Add Book button */
		purchase.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				add_book();

			}
		});

		/** set an action listener to Display button */
		display.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				display();

			}
		});
		
		/** set an action listener to Sale button */
		sale.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				sale();

			}
		});

		/** set an action listener to Search button */
		Search.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				search();

			}
		});

		/** set an action listener to report button */
		report.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				report();

			}
		});
		frame.setVisible(true);

	}

	/* method to make add book functionality* */
	public static void add_book() {
		final JFrame frame = new JFrame("Add Book");
		frame.setSize(400, 400);
		frame.setLocation(200, 200);
		frame.setResizable(false);
		frame.setLayout(new BorderLayout());

		JPanel p1 = new JPanel();
		JButton exit = new JButton("Exit");
		JButton save = new JButton("Save");
		p1.add(exit);
		p1.add(save);
		frame.add(p1, BorderLayout.SOUTH);

		JPanel p2 = new JPanel();
		p2.setBorder(new TitledBorder("Add"));
		p2.setLayout(new GridLayout(6, 2));

		JLabel l1 = new JLabel("Author");
		JLabel l2 = new JLabel("Title");
		JLabel l3 = new JLabel("Edition");
		JLabel l4 = new JLabel("Publisher");
		JLabel l5 = new JLabel("Price");
		JLabel l6 = new JLabel("Quantity");

		final JTextField t1 = new JTextField();
		final JTextField t2 = new JTextField();
		final JTextField t3 = new JTextField();
		final JTextField t4 = new JTextField();
		final JTextField t5 = new JTextField();
		final JTextField t6 = new JTextField();

		p2.add(l1);
		p2.add(t1);
		p2.add(l2);
		p2.add(t2);
		p2.add(l3);
		p2.add(t3);
		p2.add(l4);
		p2.add(t4);
		p2.add(l5);
		p2.add(t5);
		p2.add(l6);
		p2.add(t6);

		frame.add(p2);

		exit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				frame.setVisible(false);
			}
		});

		save.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					int n = Integer.parseInt(t6.getText());
					/** create a new object of Class Book */
					Book book = new Book(t1.getText(), t2.getText(), t3
							.getText(), t4.getText(), t5.getText(), n);

					Node node = book_list.first;
					boolean t = false;

					/** For loop to find if the new book exist in the list */
					for (int i = 0; i < book_list.getSize(); i++) {
						Book b = (Book) node.element;

						if (b.getTitle().equals(book.getTitle())
								&& b.getAuthor().equals(book.getAuthor())
								&& b.getEdition().equals(book.getEdition())
								&& b.getPublisher().equals(book.getPublisher())) {
							b.setQuantity(book.getQuantity() + b.getQuantity());

							try {
								writeFile();
							} catch (Exception e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}

							t = true;
							break;

						}

						else
							node = node.next;
					}

					if (t == false) {
						book_list.addLast(book);
						try {
							writeFile();
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}

					}

					JOptionPane.showMessageDialog(null, "Done!");

				} catch (NumberFormatException nfe) {
					JOptionPane.showMessageDialog(null,
							"Enter a numerical number in the quantity Field");
				}

			}
		});

		frame.setVisible(true);

	}

	/* method display to display all books on text area * */
	public static void display() {
		final JFrame f = new JFrame("Display All Book ");
		f.setLayout(new BorderLayout());
		f.setSize(500, 500);
		f.setResizable(false);
		f.setLocation(300, 150);
		JPanel p2 = new JPanel();
		p2.setLayout(new FlowLayout());
		JButton exit = new JButton("Exit");
		p2.add(exit);

		exit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				f.setVisible(false);

			}
		});
		f.add(p2, BorderLayout.SOUTH);

		JPanel p3 = new JPanel();
		final JTextArea t = new JTextArea(25, 40);
		JScrollPane scroll = new JScrollPane(t);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

		p3.add(scroll);
		f.add(p3, BorderLayout.CENTER);

		Node temp = book_list.first;
		for (int i = 0; i < book_list.getSize(); i++) {
			Book s = temp.element;
			t.setText(t.getText() + "( " + s.toString() + " ) " + "\n");

			temp = temp.next;

		}

		t.setEditable(false);

		f.setVisible(true);

	}

	/* method to make search functionality* */
	public static void search() {

		final JFrame frame = new JFrame("Search for a Book");
		frame.setSize(400, 400);
		frame.setLocation(200, 200);
		frame.setResizable(false);
		frame.setLayout(new BorderLayout());

		JPanel p1 = new JPanel();
		JButton exit = new JButton("Exit");

		p1.add(exit);
		frame.add(p1, BorderLayout.SOUTH);

		JPanel p2 = new JPanel();
		p2.setBorder(new TitledBorder(
				"Search use title (or part of the title) or the author"));

		final JComboBox<String> box = new JComboBox<String>(new String[] {
				"Select", "Title", "Part of title", "Author" });
		final JTextField t1 = new JTextField(15);
		final JButton b0 = new JButton("Search");
		frame.setVisible(true);

		p2.add(box);
		p2.add(t1);
		p2.add(b0);

		JPanel p3 = new JPanel();
		final JTextArea t3 = new JTextArea(14, 33);
		t3.setEditable(false);
		JScrollPane scroll = new JScrollPane(t3);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

		t3.setSize(200, 200);
		p3.add(scroll);

		frame.add(p2, BorderLayout.NORTH);
		frame.add(p3);
		frame.setVisible(true);

		b0.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub

				t3.setText("");

				if (box.getSelectedIndex() == 1) {
					String s = t1.getText();
					Node node = book_list.first;

					for (int i = 0; i < book_list.getSize(); i++) {
						Book book = node.element;
						if (s.compareToIgnoreCase(book.getTitle()) == 0) {
							t3.setText(t3.getText() + book.toString() + "\n");

						}
						node = node.next;

					}

				}

				else if (box.getSelectedIndex() == 2) {
					String s = t1.getText();
					Node node = book_list.first;

					for (int i = 0; i < book_list.getSize(); i++) {
						Book book = node.element;
						String title = book.getTitle();

						if (title.contains(s)) {
							t3.setText(t3.getText() + book.toString() + "\n");
						}
						node = node.next;
					}

				} else if (box.getSelectedIndex() == 3) {
					String s = t1.getText();

					Node node = book_list.first;

					for (int i = 0; i < book_list.getSize(); i++) {
						Book book = node.element;
						String auther = book.getAuthor();

						if (auther.contains(s)) {
							t3.setText(t3.getText() + book.toString() + "\n");
						}

						node = node.next;
					}

				}

				else {
					JOptionPane.showMessageDialog(null, "select option");
				}

			}
		});

		exit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				frame.setVisible(false);
			}
		});

	}

	/* method to make sale functionality* */
	public static void sale() {

		final JFrame frame = new JFrame("Selling books");
		frame.setSize(400, 400);
		frame.setLocation(200, 200);
		frame.setResizable(false);
		frame.setLayout(new BorderLayout());

		JPanel p1 = new JPanel();
		JButton exit = new JButton("Exit");
		JButton sale = new JButton("Sale");
		p1.add(exit);
		p1.add(sale);
		frame.add(p1, BorderLayout.SOUTH);

		JPanel p2 = new JPanel();
		p2.setBorder(new TitledBorder("Sale"));
		p2.setLayout(new GridLayout(6, 2));

		JLabel l1 = new JLabel("Author");
		JLabel l2 = new JLabel("Title");
		JLabel l3 = new JLabel("Edition");
		JLabel l4 = new JLabel("Publisher");
		JLabel l6 = new JLabel("Quantity");

		final JTextField t1 = new JTextField();
		final JTextField t2 = new JTextField();
		final JTextField t3 = new JTextField();
		final JTextField t4 = new JTextField();
		final JTextField t6 = new JTextField();

		p2.add(l1);
		p2.add(t1);
		p2.add(l2);
		p2.add(t2);
		p2.add(l3);
		p2.add(t3);
		p2.add(l4);
		p2.add(t4);
		p2.add(l6);
		p2.add(t6);

		frame.add(p2);

		exit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				frame.setVisible(false);
			}
		});

		sale.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				Node node = book_list.first;

				/** For loop to find if the new book exist in the list */
				for (int i = 0; i < book_list.getSize(); i++) {
					Book b = (Book) node.element;

					if (b.getTitle().equals(t2.getText())
							&& b.getAuthor().equals(t1.getText())
							&& b.getEdition().equals(t3.getText())
							&& b.getPublisher().equals(t4.getText())) {

						if (Integer.parseInt(t6.getText()) <= b.getQuantity()) {
							b.setQuantity(b.getQuantity()
									- Integer.parseInt(t6.getText()));
							JOptionPane
									.showMessageDialog(null, "The book sale");
							if (b.getQuantity() == 0) {
								book_list.remove(node);

							}
						}

						else {
							JOptionPane.showMessageDialog(null,
									"There is not sufficient number of books");
						}

						try {
							writeFile();
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}

						break;

					}

					else {
						if (node.next != null) {
							node = node.next;
						} else
							JOptionPane.showMessageDialog(null,
									"the book not exist");

					}
				}

			}
		});

		frame.setVisible(true);

	}

	/* method to make report functionality* */
	public static void report() {

		final JFrame f = new JFrame("Display All Book sorted based on title");
		f.setLayout(new BorderLayout());
		f.setSize(500, 500);
		f.setResizable(false);
		f.setLocation(300, 150);
		JPanel p2 = new JPanel();
		p2.setLayout(new FlowLayout());
		JButton exit = new JButton("Exit");
		p2.add(exit);

		exit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				f.setVisible(false);

			}
		});
		f.add(p2, BorderLayout.SOUTH);

		JPanel p3 = new JPanel();
		final JTextArea t = new JTextArea(25, 40);
		JScrollPane scroll = new JScrollPane(t);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

		p3.add(scroll);
		f.add(p3, BorderLayout.CENTER);

		Book[] array = new Book[book_list.getSize()];

		array = listToArray(book_list);

		MergeSort.mergeSort(array);
		LinkedList list = arrayToList(array);

		Node temp = list.first;
		for (int i = 0; i < list.getSize(); i++) {
			Book s = temp.element;
			t.setText(t.getText() + "( " + s.toString() + " ) " + "\n");

			temp = temp.next;

		}

		t.setEditable(false);

		f.setVisible(true);

	}

	/* method to convert linked list to array * */
	public static Book[] listToArray(LinkedList list) {
		Book[] array = new Book[list.getSize()];

		Node node = list.first;
		for (int i = 0; i < array.length; i++) {
			array[i] = node.element;
			node = node.next;
		}

		return array;

	}

	/* method to convert array to linked list* */
	public static LinkedList arrayToList(Book[] array) {
		LinkedList list = new LinkedList();

		for (int i = 0; i < array.length; i++) {
			list.addLast(array[i]);

		}

		return list;

	}

	/* method to print list on file * */
	public static void writeFile() throws Exception {
		if (CheckReadOnlyMode()) {
			JOptionPane.showMessageDialog(null,
					"We can't write in this file because its read only");

		} else {
			File fout = new File("Book.txt");
			FileOutputStream fos = new FileOutputStream(fout);
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

			if (fout.canWrite() == false) {

			}
			Node node = book_list.first;
			for (int i = 0; i < book_list.getSize(); i++) {
				bw.write(node.element.toString());
				bw.newLine();
				node = node.next;

			}
			bw.close();

		}

	}

	/* method to check if the file can write or not* */
	public static boolean CheckReadOnlyMode() {
		File file = new File("Book.txt");
		boolean b = file.canWrite();
		if (b == false) {
			return true;
		} else {
			return false;
		}
	}

}
