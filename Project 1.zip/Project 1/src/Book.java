/*Class Book **/
public class Book {
	/* Data field* */
	private String author;
	private String title;
	private String edition;
	private String publisher;
	private String price;
	private int quantity;

	/** no argument constructor */

	public Book() {

	}

	/** argument constructor */
	public Book(String author, String title, String edition, String publisher,
			String price, int quantity) {
		super();
		this.author = author;
		this.title = title;
		this.edition = edition;
		this.publisher = publisher;
		this.price = price;
		this.quantity = quantity;
	}

	/**
	 * @return the author
	 */
	public String getAuthor() {
		return author;
	}

	/**
	 * @param author
	 *            the author to set
	 */
	public void setAuthor(String author) {
		this.author = author;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title
	 *            the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the edition
	 */
	public String getEdition() {
		return edition;
	}

	/**
	 * @param edition
	 *            the edition to set
	 */
	public void setEdition(String edition) {
		this.edition = edition;
	}

	/**
	 * @return the publisher
	 */
	public String getPublisher() {
		return publisher;
	}

	/**
	 * @param publisher
	 *            the publisher to set
	 */
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	/**
	 * @return the price
	 */
	public String getPrice() {
		return price;
	}

	/**
	 * @param price
	 *            the price to set
	 */
	public void setPrice(String price) {
		this.price = price;
	}

	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity
	 *            the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	/* method toString to return Data* */
	public String toString() {
		return author + ":" + title + ":" + edition + ":" + publisher + ":"
				+ price + ":" + quantity;
	}

}
