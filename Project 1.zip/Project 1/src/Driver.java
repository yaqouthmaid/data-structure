/*class Driver**/
public class Driver {
	/* main method* */
	public static void main(String[] args) {
		new Gui();

	}

}
