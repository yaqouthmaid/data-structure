/** class Node */
public class Node {

	/** Data filed */
	Book element;
	Node next;

	/** no argument Constructor */
	public Node() {

	}

	/** argument constructor */
	public Node(Book element) {
		this.element = element;

	}

}
