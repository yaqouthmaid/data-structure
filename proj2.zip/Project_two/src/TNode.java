public class TNode <T extends Comparable<T>>{
	T data;
	 TNode<T> right;
	 TNode<T> left;

	public TNode() {

	}

	public TNode (T data) {
		this.data = data;
	}
	public void setData(T data) {
		this.data=data;
	}
	public T getData() { return data;
	}
	public TNode<T> getLeft() {
		return left; }
	public void setLeft(TNode<T> left) {
		this.left = left;
	}
	public TNode <T>getRight() {
		return right;
	}
	public void setRight(TNode<T> right) {
		this.right = right;
	}
	public boolean isLeaf(){
		return (left==null && right==null);
	}
	public boolean hasLeft(){
		return left!=null;
	}
	public boolean hasRight(){
		return right!=null;
	}
	public Name make() {
		Name n = (Name) data ;
		return n;
	}
	
	public TNode finds(String data) {
		if (this.make().getName().compareTo(data) == 0)
			return this;
		if (data.compareTo(this.make().getName()) < 0 && left != null) {
			return left.finds(data);
		}
		if (right != null)
			return right.finds(data);
		return null;

	}
	public String retuenName() {
		
		return this.make().getName();
		
		
	}
public String returngen() {
	return this.make().getGender();
}
	@Override
	public String toString() {
		return data + "-";
	}
	
	public int reFrq() {
		return this.make().retuenFreq();
	}

	public int reFrrq() {
		// TODO Auto-generated method stub
		return 0;
	}

	static TNode maxValue(TNode node) 
	{  
	    /* loop down to find the rightmost leaf */
	    TNode current = node; 
	    while (current.right != null)  
	        current = current.right; 
	      
	    return (current); 
	} 

	
	



}