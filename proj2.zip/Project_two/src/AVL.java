import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Queue;

public class AVL<T extends Comparable<T>> {
	TNode<T> root;
    FileOutputStream outputStream = null;


	public AVL(TNode<T> root) {
		this.root = root;
	}

	public AVL() {

	}

	public TNode<T> getRoot() {
		return root;
	}

	public void setRoot(TNode<T> root) {
		this.root = root;
	}

	public int height(TNode<T> node) {
		if (node == null)
			return 0;
		if (node.getRight() == null && node.getLeft() == null)
			return 1;
		int left = 0;
		int right = 0;
		if (node.getLeft() != null)
			left = height(node.getLeft());
		if (node.getRight() != null)
			right = height(node.getRight());
		return (left > right) ? (left + 1) : (right + 1);
	}

	private int heightDifference(TNode<T> node) {
// System.out.println(node);
		return (height(node.getLeft()) - height(node.getRight()));
	}

// left-left addition
	private TNode<T> singleRightRotaion(TNode<T> Node) {
		TNode<T> curr = Node.getLeft();
		Node.setLeft(curr.getRight());
		curr.setRight(Node);
		return curr;

	}

// right-right addition
	private TNode<T> singleLeftRotation(TNode<T> Node) {
		TNode<T> curr = Node.getRight();
		Node.setRight(curr.getLeft());
		curr.setLeft(Node);
		return curr;

	}

// right-left double addition
	private TNode<T> doubleRightLeftAdittion(TNode<T> Node) {
		TNode<T> curr = Node.getRight();
		Node.setRight(singleRightRotaion(curr));
		return singleLeftRotation(Node);

	}

// left-right double rotation
	private TNode<T> doubleLeftRightRotation(TNode<T> Node) {
		TNode<T> curr = Node.getLeft();
		Node.setLeft(singleLeftRotation(curr));
		return singleRightRotaion(Node);
	}

// Method to rebalance the tree when adding
	public TNode<T> rebalance(TNode<T> node) {
		int diff = heightDifference(node);
		if (diff > 1) {

			if (node.getLeft() != null && heightDifference(node.getLeft()) > 0)
				node = singleRightRotaion(node);
			else {
				node = doubleLeftRightRotation(node);
			}
		} else if (diff < -1) {

			if (node.getRight() != null && heightDifference(node.getRight()) < 0)
				node = singleLeftRotation(node);
			else {
				node = doubleRightLeftAdittion(node);
			}
		}
		return node;

	}

	public void traverseInOrder(TNode<T> node) {
		if (node != null) {
			if (node.getLeft() != null)
				traverseInOrder(node.getLeft());

			System.out.println(node + " ");

			if (node.getRight() != null)
				traverseInOrder(node.getRight());
		}
	}
	

	public void insert(T data) {
		TNode<T> node = new TNode<T>(data);
		if (root == null)
			root = node;
		else {
			TNode<T> rootNode = root;
			insert(data, rootNode);
			root = rebalance(rootNode);
		}

	}

	private void insert(T data, TNode<T> rootNode) {
		assert rootNode != null;
		if (data.compareTo((T) rootNode.getData()) < 0) {
			if (rootNode.getLeft() != null) {
				TNode<T> leftChild = rootNode.getLeft();
				insert(data, leftChild);
				rootNode.setLeft(rebalance(leftChild));
			} else
				rootNode.setLeft(new TNode<T>(data));
			;
		} else { // right into right subtree
			if (rootNode.getRight() != null) {
				TNode<T> rightChild = rootNode.getRight();
				insert(data, rightChild);
				rootNode.setRight(rebalance(rightChild));
			} else
				rootNode.setRight(new TNode<T>(data));
			;
		}
	}

	public TNode<T> find(T data) {

		return find(data, root);
	}

	public TNode<T> find(T data, TNode<T> node) {
		if (node != null) {
			int comp = node.getData().compareTo(data);
			if (comp == 0)
				return node;
			else if (comp > 0 && node.hasLeft())
				return find(data, node.getLeft());
			else if (comp < 0 && node.hasRight())
				return find(data, node.getRight());
		}
		return null;
	}

	public TNode finds(String m) {

		if (root != null) {
			return root.finds(m);
		} else {
			return null;
		}
	}

	static TNode findMax(TNode node) {
		if (node == null)
			return node;
		TNode max = node;
		int res = max.reFrq();
		TNode lres = findMax(node.left);
		TNode rres = findMax(node.right);

		if (lres.reFrq() > res) {
			max = node.left;
		}
		if (rres.reFrq() > res) {
			max = node.right;
		}
		return max;
	}

	private int maxElem(TNode node) {
		int max = node.reFrq();
		if (node.left != null) {
			max = Math.max(max, maxElem(node.left));
		}
		if (node.right != null) {
			max = Math.max(max, maxElem(node.right));
		}
		return max;
	}

	public TNode maxElem1(TNode node) {
		int max = node.reFrq();
		TNode current = node;

		if (node.left != null) {
			max = Math.max(max, maxElem(node.left));
			current = node.left;
		}
		if (node.right != null) {
			max = Math.max(max, maxElem(node.right));
			current = node.right;
		}
		return current;
	}

	static int addBT(TNode r) {
		if (r == null)
			return 0;
		return (r.reFrq() + addBT(r.left) + addBT(r.right));
	}

	static public void levelOrderNaiveApproach(TNode root) {
		int h = heightt(root);

		for (int i = 1; i <= h; i++) {
			printLevels(root, i);
			System.out.println("");

		}
	}

	static public void printLevels(TNode root, int h) {
		if (root == null)
			return;
		if (h == 1)
			System.out.print(" " + root.data);
		else {
			printLevels(root.left, h - 1);
			printLevels(root.right, h - 1);
		}
	}

	static public int heightt(TNode root) {
		if (root == null)
			return 0;
		return 1 + Math.max(heightt(root.left), heightt(root.right));
	}

	static public void levelOrderQueue(Node root) {
		Queue q = (Queue) new LinkedList();
		int levelNodes = 0;
		if (root == null)
			return;
		q.add(root);
		while (!q.isEmpty()) {
			levelNodes = q.size();
			while (levelNodes > 0) {
				TNode n = (TNode) q.remove();
				System.out.print(" " + n.data);
				if (n.left != null)
					q.add(n.left);
				if (n.right != null)
					q.add(n.right);
				levelNodes--;
			}
			System.out.println("");
		}
	}

	public TNode<Name> searchName(String data) { // utility function
		return searchName(data, root);
	}

	public TNode<Name> searchName(String data, TNode t) {
		while (t != null) {
			if (((Name) t.getData()).getName().compareToIgnoreCase(data) > 0) // data < t.data
				t = t.getLeft();
			else if (((Name) t.getData()).getName().compareToIgnoreCase(data) < 0) // data > t.data
				t = t.getRight();
			else
				return t; // Match found
		}
		return null; // No match

	}
	public void writeFile(TNode mainNode)
	{
	    FileOutputStream outputStream = null;
	    PrintWriter printWriter = null;

	    try
	    {

	        outputStream = new FileOutputStream("file.txt");
	        printWriter = new PrintWriter(outputStream); 

	        write(mainNode, printWriter);

	        printWriter.flush();

	  }catch(IOException e)
	  {
	     System.out.println("An error occured");
	      printWriter.close();
	  }

	}

	 public void write(TNode mainNode, PrintWriter w)
	 {
	     if(mainNode != null){
	      write(mainNode.left, w);
	      w.print(mainNode + "\n");
	      write(mainNode.right, w); 
	    }
	 }
	

public String findMaxx(){
    TNode result = root;
    result = findMaxx( root,result);
    return result.retuenName();
}

public TNode findMaxx(TNode node,TNode result){
    if (node == null){
        return result;
    }
    if (node.reFrq() > result.reFrq() || 
            (node.reFrq() == result.reFrq() && node.data.compareTo(result.data) < 0)){
        result = node;
    }
    result = findMaxx(node.left,result);
    result = findMaxx(node.right,result);
    return result;
}
}
//public T finds(String name) {
//
//return finds(name, root);
//}
//
//public T finds(String data, TNode<T> node) {
//if (node != null) {
//int comp = node.getData().compareTo((T) data);
//if (comp == 0)
//return node.getData();
//else if (comp > 0 && node.hasLeft())
//return finds(data, node.getLeft());
//else if (comp < 0 && node.hasRight())
//return finds(data, node.getRight());
//}
//return null;
//}
//public Comparable finds( Comparable x )
//{
//    return elementAt( finds( x, root ) );
//}
//private Comparable elementAt( TNode t )
//{
//    return t == null ? null : t.data;
//}
//private TNode finds( Comparable x, TNode t )
//{
//    while( t != null )
//        if( x.compareTo( t.getData() ) < 0 )
//            t = t.left;
//        else if( x.compareTo( t.getData() ) > 0 )
//            t = t.right;
//        else
//            return t;    // Match
//
//    return null;   // No match
//}

//public T findMax() {
//	return findMax(root).getData().toString();
//}
//
//private TNode<T> findMax(T curr) {
//	if (curr.getRight() == null)
//		return curr;
//	else
//		return findMax(curr.getRight());
//}
