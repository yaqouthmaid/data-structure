public class Node<T extends Comparable<T>> {

	T data;
	Node<T> node; //this should be named next!!

	@Override
	public String toString() {
		return "Node [data=" + data + "]";
	}

	public Node(T data) {

		this.data = data;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	public Node<T> getNode() {
		return node;
	}

	public void setNode(Node<T> node) {
		this.node = node;
	}
	public Frequency made() {
		Frequency n = (Frequency) data;
		return n;
	}

	public int retuenFreq() {

		return this.made().Ffreq;

	}


}
