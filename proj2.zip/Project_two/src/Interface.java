import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.util.Enumeration;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;
import javax.swing.JComboBox;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.MalformedInputException;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.print.DocFlavor.INPUT_STREAM;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;

public class Interface {

	private JFrame frame;
	private JTextField NameS;
	private JTextField NameFreq;
	static AVL<Name> tree = new AVL<Name>();
	static ButtonGroup btnGrp = new ButtonGroup();
	static ButtonGroup btnGrp2 = new ButtonGroup();
	static File file;
	int totalInYear = 0;
	FileOutputStream outputStream = null;
	PrintWriter printWriter = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		Interface window = new Interface();
		window.frame.setVisible(true);

//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					Interface window = new Interface();
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
	}

	/**
	 * Create the application.
	 */
	public Interface() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 218, 185));
		frame.setBounds(100, 100, 675, 427);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		for (int i = 0; i < 18; i++) {
			int year = 2000 + i;
			File file = new File("USA_yob" + year + ".txt");
			// System.out.println(file.exists());
			// hey
			try {
				Scanner scan = new Scanner(file);
				while (scan.hasNextLine()) {
					String l = scan.nextLine();
					// System.out.println("ss "+line);;
					String tokens[] = l.split(",");
					if (tokens.length == 3) {
						Name name = new Name(tokens[0], tokens[1]);
						int freq = Integer.parseInt(tokens[2]);
						Frequency f = new Frequency(year, freq);

						if (tree.find(name) == null) {
							name.AddToLinkedlist(f);
							tree.insert(name);
						} else {
							// System.out.println(tree.find(name));
							(tree.find(name)).getData().AddToLinkedlist(f);
						}
					}

				}
				System.out.println("finished reading " + year);
			} catch (Exception e1) {
				// TODO: handle exception
				e1.printStackTrace();
				// System.out.println(e1.printStackTrace());
			}
		}
		// tree.traverseInOrder(tree.getRoot());

		JLabel lblSearchingForName = new JLabel("Searching for name :");
		lblSearchingForName.setBounds(10, 23, 139, 25);
		frame.getContentPane().add(lblSearchingForName);

		NameS = new JTextField();
		NameS.setBounds(104, 57, 86, 20);
		frame.getContentPane().add(NameS);
		NameS.setColumns(10);

		JLabel lblEnterName = new JLabel("Enter Name");
		lblEnterName.setBounds(10, 59, 84, 14);
		frame.getContentPane().add(lblEnterName);

		JLabel lblGender = new JLabel("Gender");
		lblGender.setBounds(10, 95, 46, 14);
		frame.getContentPane().add(lblGender);

		JRadioButton Female = new JRadioButton("Female");
		Female.setBackground(new Color(255, 218, 185));
		Female.setBounds(81, 91, 86, 23);
		frame.getContentPane().add(Female);

		JRadioButton Male = new JRadioButton("Male");
		Male.setBackground(new Color(255, 218, 185));
		Male.setBounds(168, 91, 109, 23);
		frame.getContentPane().add(Male);
		btnGrp.add(Male);
		btnGrp.add(Female);

		JSeparator separator = new JSeparator();
		separator.setForeground(Color.BLACK);
		separator.setBackground(new Color(169, 169, 169));
		separator.setBounds(10, 185, 280, 6);
		frame.getContentPane().add(separator);

		JLabel lblNewLabel = new JLabel("Average Frequencies of a Name:");
		lblNewLabel.setBounds(10, 197, 210, 14);
		frame.getContentPane().add(lblNewLabel);

		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				search();
			}
		});
		btnSearch.setBounds(78, 138, 89, 23);
		frame.getContentPane().add(btnSearch);

		JLabel lblEnterName_1 = new JLabel("Enter Name ");
		lblEnterName_1.setBounds(25, 255, 69, 14);
		frame.getContentPane().add(lblEnterName_1);

		NameFreq = new JTextField();
		NameFreq.setBounds(104, 252, 86, 20);
		frame.getContentPane().add(NameFreq);
		NameFreq.setColumns(10);

		JButton btnAverage = new JButton("Average");
		btnAverage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				avg();
			}
		});
		btnAverage.setBounds(78, 319, 89, 23);
		frame.getContentPane().add(btnAverage);

		JButton btnMax = new JButton("Name with \r\nmax frequency");
		btnMax.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				max();

			}
		});
		btnMax.setBounds(382, 251, 233, 69);
		frame.getContentPane().add(btnMax);

		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(Color.BLACK);
		separator_1.setBackground(new Color(211, 211, 211));
		separator_1.setBounds(369, 180, 280, 6);
		frame.getContentPane().add(separator_1);

		JSeparator separator_2 = new JSeparator();
		separator_2.setOrientation(SwingConstants.VERTICAL);
		separator_2.setForeground(Color.BLACK);
		separator_2.setBackground(new Color(211, 211, 211));
		separator_2.setBounds(325, 42, 8, 317);
		frame.getContentPane().add(separator_2);

		JLabel lblNewLabel_1 = new JLabel("Total number of babies in a selected year ");
		lblNewLabel_1.setBounds(357, 28, 258, 14);
		frame.getContentPane().add(lblNewLabel_1);

		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(
				new String[] { "Year", "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009",
						"2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018" }));
		comboBox.setBounds(461, 76, 84, 20);
		frame.getContentPane().add(comboBox);

		JRadioButton rdbtnFemale = new JRadioButton("Female");
		rdbtnFemale.setBackground(new Color(255, 222, 173));
		rdbtnFemale.setBounds(81, 276, 69, 23);
		frame.getContentPane().add(rdbtnFemale);

		JRadioButton rdbtnMale = new JRadioButton("Male");
		rdbtnMale.setBackground(new Color(255, 218, 185));
		rdbtnMale.setBounds(168, 279, 109, 23);
		frame.getContentPane().add(rdbtnMale);
		btnGrp2.add(rdbtnFemale);

		btnGrp2.add(rdbtnMale);

		JButton totalButton = new JButton("Total");
		totalButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				final JFrame frame = new JFrame("Frequency Result");
				frame.setSize(400, 300);
				frame.setLocation(200, 100);
				frame.setResizable(false);
				frame.getContentPane().setLayout(new BorderLayout());

				JPanel p1 = new JPanel();
				JButton exit = new JButton("Exit");

				p1.add(exit);
				frame.getContentPane().add(p1, BorderLayout.SOUTH);

				JPanel p3 = new JPanel();
				final JTextArea t3 = new JTextArea(14, 33);
				t3.setEditable(false);
				JScrollPane scroll = new JScrollPane(t3);
				scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

				t3.setSize(200, 200);
				p3.add(scroll);

				frame.getContentPane().add(p3);
				frame.setVisible(true);
				t3.setText(" ");

				totalInYear = 0;
				int selYear = Integer.parseInt(comboBox.getSelectedItem().toString().trim());
				;
				traverse(tree.root, selYear);
				t3.setText(totalInYear + "");
			}

			private void extracted() {
				// TODO Auto-generated method stub

			}
		});
		totalButton.setBounds(461, 125, 89, 23);
		frame.getContentPane().add(totalButton);

		JSeparator separator_3 = new JSeparator();
		separator_3.setForeground(Color.BLACK);
		separator_3.setBackground(new Color(169, 169, 169));
		separator_3.setBounds(10, 180, 280, 6);
		frame.getContentPane().add(separator_3);

		JSeparator separator_4 = new JSeparator();
		separator_4.setForeground(Color.BLACK);
		separator_4.setBackground(new Color(169, 169, 169));
		separator_4.setBounds(369, 185, 280, 6);
		frame.getContentPane().add(separator_4);

		JSeparator separator_5 = new JSeparator();
		separator_5.setOrientation(SwingConstants.VERTICAL);
		separator_5.setForeground(Color.BLACK);
		separator_5.setBackground(new Color(211, 211, 211));
		separator_5.setBounds(320, 42, 8, 317);
		frame.getContentPane().add(separator_5);

		JButton btnExport = new JButton("export");
		btnExport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				exports();

			}
		});
		btnExport.setBounds(456, 331, 89, 23);
		frame.getContentPane().add(btnExport);
	}

	public void traverse(TNode<Name> node, int year) {
		if (node != null) {
			if (node.getLeft() != null)
				traverse(node.getLeft(), year);
			totalInYear += node.getData().getNumberInYear(year);

			if (node.getRight() != null)
				traverse(node.getRight(), year);
		}

	}

	public void search() {
		final JFrame frame = new JFrame("Search Result");
		frame.setSize(400, 400);
		frame.setLocation(200, 200);
		frame.setResizable(false);
		frame.getContentPane().setLayout(new BorderLayout());

		JPanel p1 = new JPanel();
		JButton exit = new JButton("Exit");

		p1.add(exit);
		frame.getContentPane().add(p1, BorderLayout.SOUTH);

		JPanel p3 = new JPanel();
		final JTextArea t3 = new JTextArea(14, 33);
		t3.setEditable(false);
		JScrollPane scroll = new JScrollPane(t3);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

		t3.setSize(200, 200);
		p3.add(scroll);

		frame.getContentPane().add(p3);
		frame.setVisible(true);
		t3.setText(" ");
		try {
			String ch = getSelectedButtonText(btnGrp);
			String name = NameS.getText();
			TNode m = tree.searchName(name);
			String fin = m.retuenName();

			if (ch == "Male") {
				String gen = "M";
				if (name.compareToIgnoreCase(fin) == 0 && gen.compareToIgnoreCase(m.returngen()) == 0) {
					t3.setText(t3.getText() + fin + "\n" + m.data.toString() + "\n");

				}

			}

			if (ch == "Female") {
				String gen = "F";
				if (name.compareToIgnoreCase(fin) == 0 && gen.compareToIgnoreCase(m.returngen()) == 0) {
					t3.setText(t3.getText() + fin + "\n" + m.data.toString() + "\n");

				}
			}

		} catch (NullPointerException ex) {
			t3.setText("there's No Such Name !!!! ");
		}

	}

	public void avg() {

		final JFrame frame = new JFrame("Frequency Result");
		frame.setSize(400, 300);
		frame.setLocation(200, 100);
		frame.setResizable(false);
		frame.getContentPane().setLayout(new BorderLayout());

		JPanel p1 = new JPanel();
		JButton exit = new JButton("Exit");

		p1.add(exit);
		frame.getContentPane().add(p1, BorderLayout.SOUTH);

		JPanel p3 = new JPanel();
		final JTextArea t3 = new JTextArea(14, 33);
		t3.setEditable(false);
		JScrollPane scroll = new JScrollPane(t3);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

		t3.setSize(200, 200);
		p3.add(scroll);

		frame.getContentPane().add(p3);
		frame.setVisible(true);
		t3.setText(" ");
		float sumOfFreq = 0;

		try {
			String ch = getSelectedButtonText(btnGrp2);
			String name = NameFreq.getText().trim();
			TNode<Name> m = tree.searchName(name);
			String fin = m.retuenName();
			LinkedList<Frequency> fList = m.getData().getFrequency();

			Node<Frequency> head = fList.getNode();

			int count = 0;
			if (ch == "Male") {
				String gen = "M";
				if (name.compareToIgnoreCase(fin) == 0 && gen.compareToIgnoreCase(m.returngen()) == 0) {
					while (head != null) {
						sumOfFreq += head.data.Ffreq;
						count += 1;
						head = head.getNode();
					}
					// sumOfFreq = sumOfFreq + m.reFrq();
					float avg = (count == 0) ? 0 : sumOfFreq / (float) count;
					String r = Float.toString(avg);
					t3.setText(r);
				}

			}

			if (ch == "Female") {
				String gen = "F";
				if (name.compareToIgnoreCase(fin) == 0 && gen.compareToIgnoreCase(m.returngen()) == 0) {
					while (head != null) {
						sumOfFreq += head.data.Ffreq;
						count += 1;
						head = head.getNode();
					}
					// sumOfFreq = sumOfFreq + m.reFrq();
					float avg = (count == 0) ? 0 : sumOfFreq / (float) count; //
					String r = Float.toString(avg);
					t3.setText(r);

				}
			}

		} catch (NullPointerException ex) {
			t3.setText("there's No Such Name !!!! ");
		}

	}

	public void max() {

		final JFrame frame = new JFrame("Frequency Result");
		frame.setSize(400, 300);
		frame.setLocation(200, 100);
		frame.setResizable(false);
		frame.getContentPane().setLayout(new BorderLayout());

		JPanel p1 = new JPanel();
		JButton exit = new JButton("Exit");

		p1.add(exit);
		frame.getContentPane().add(p1, BorderLayout.SOUTH);

		JPanel p3 = new JPanel();
		final JTextArea t3 = new JTextArea(14, 33);
		t3.setEditable(false);
		JScrollPane scroll = new JScrollPane(t3);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

		t3.setSize(200, 200);
		p3.add(scroll);

		frame.getContentPane().add(p3);
		frame.setVisible(true);
		t3.setText(" ");
		TNode max = tree.root;

		try {

			String r = tree.findMaxx();
			{
				t3.setText(t3.getText() + "The name with most frequency is : " + r + "\n");

			}

		} catch (Exception e) {

		}

	}

	public String getSelectedButtonText(ButtonGroup buttonGroup) {
		for (Enumeration<AbstractButton> buttons = buttonGroup.getElements(); buttons.hasMoreElements();) {
			AbstractButton button = buttons.nextElement();

			if (button.isSelected()) {
				return button.getText();
			}
		}

		return null;
	}

	public void exports() {

		tree.writeFile(tree.root);

	}

}
