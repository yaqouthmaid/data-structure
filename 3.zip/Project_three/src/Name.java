
public class Name implements Comparable<Name> {

	private String name;
	private String gender;
	private Heap<Frequency> frequency = new Heap<Frequency>();

	public Name(String name, String gender) {
		super();
		this.name = name;
		this.gender = gender;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void AddToLinkedlist(Frequency freq) {
		frequency.add(freq);
	}

	@Override
	public String toString() {
		return "Name [name=" + name + ", gender=" + gender + ", freq=" + frequency + "]";
	}

	@Override
	public int compareTo(Name o) {
		// TODO Auto-generated method stub
		if (name.equals(o.name)) {
			return getGender().compareTo(o.getGender());
			// gender is string u can't subtrac them
		}

		return name.compareTo(o.name);
	}

	public Name getData() {
		// TODO Auto-generated method stub
		return null;
	}

	




}
