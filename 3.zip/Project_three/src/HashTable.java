
public class HashTable {

	public HashTable() {
		// TODO Auto-generated constructor stub
	}

}
