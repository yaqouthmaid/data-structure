
public class Frequency implements Comparable<Frequency> {
	int year ;
	int Ffreq;
	
	@Override
	public String toString() {
		return "Frequency [year=" + year + ", Ffreq=" + Ffreq + "]";
	}

	public Frequency(int year, int ffreq) {
		super();
		this.year = year;
		this.Ffreq = ffreq;
	}

	@Override
	public int compareTo(Frequency o) {
		// TODO Auto-generated method stub
		return year-o.year;
	}
	
	




}
