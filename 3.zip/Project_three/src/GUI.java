import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import java.awt.Cursor;
import java.awt.Component;
import javax.swing.SwingConstants;

public class GUI {

	private JFrame frame;
	private JTextField theName;
	private JTextField nameRecord;
	private JTextField freqRecord;
	private JTextField yearRecord;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI window = new GUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(245, 222, 179));
		frame.getContentPane().setLayout(null);

		JLabel lblrdProject = new JLabel("3rd Project");
		lblrdProject.setFont(new Font("Constantia", Font.BOLD, 17));
		lblrdProject.setBounds(650, 313, 112, 28);
		frame.getContentPane().add(lblrdProject);

		JLabel lblNewLabel = new JLabel("by : Yaqout, Sandra, Weaam.");
		lblNewLabel.setFont(new Font("Constantia", Font.BOLD, 14));
		lblNewLabel.setBounds(566, 333, 196, 50);
		frame.getContentPane().add(lblNewLabel);

		JButton maxFreqBTN = new JButton("Name with max Freq");
		maxFreqBTN.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				maxName();

			}
		});
		maxFreqBTN.setFont(new Font("Sitka Subheading", Font.BOLD, 13));
		maxFreqBTN.setBounds(160, 210, 166, 22);
		frame.getContentPane().add(maxFreqBTN);

		JLabel lblEnterAName = new JLabel("Enter A Name :");
		lblEnterAName.setFont(new Font("Sitka Subheading", Font.BOLD, 13));
		lblEnterAName.setBounds(62, 79, 96, 14);
		frame.getContentPane().add(lblEnterAName);

		theName = new JTextField();
		theName.setBounds(181, 72, 86, 28);
		frame.getContentPane().add(theName);
		theName.setColumns(10);

		JLabel lblSelectTheGender = new JLabel("Select the gender");
		lblSelectTheGender.setFont(new Font("Sitka Subheading", Font.BOLD, 12));
		lblSelectTheGender.setBounds(62, 122, 96, 14);
		frame.getContentPane().add(lblSelectTheGender);

		JRadioButton femaleBTN = new JRadioButton("Female");
		femaleBTN.setFont(new Font("Sitka Subheading", Font.BOLD, 11));
		femaleBTN.setBackground(new Color(245, 222, 179));
		femaleBTN.setBounds(175, 117, 76, 23);
		frame.getContentPane().add(femaleBTN);

		JRadioButton maleBTN = new JRadioButton("Male");
		maleBTN.setBackground(new Color(245, 222, 179));
		maleBTN.setFont(new Font("Sitka Subheading", Font.BOLD, 11));
		maleBTN.setBounds(253, 117, 76, 23);
		frame.getContentPane().add(maleBTN);

		JButton Median = new JButton("Median");
		Median.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				median();
			}
		});
		Median.setFont(new Font("Sitka Subheading", Font.BOLD, 13));
		Median.setBounds(150, 176, 94, 23);
		frame.getContentPane().add(Median);

		JButton searchBTN = new JButton("Search");
		searchBTN.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				search();
			}
		});
		searchBTN.setFont(new Font("Sitka Subheading", Font.BOLD, 13));
		searchBTN.setBounds(51, 176, 89, 23);
		frame.getContentPane().add(searchBTN);

		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				delete();
			}
		});
		btnDelete.setFont(new Font("Sitka Subheading", Font.BOLD, 13));
		btnDelete.setBounds(254, 176, 89, 23);
		frame.getContentPane().add(btnDelete);

		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addNameRecord();
			}
		});
		btnAdd.setFont(new Font("Sitka Subheading", Font.BOLD, 13));
		btnAdd.setBounds(51, 210, 89, 23);
		frame.getContentPane().add(btnAdd);

		JSeparator separator = new JSeparator();
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBounds(381, 46, 5, 300);
		frame.getContentPane().add(separator);

		JLabel lblNewLabel_1 = new JLabel("- Manipulating year/freq records area :");
		lblNewLabel_1.setFont(new Font("Sitka Subheading", Font.BOLD, 12));
		lblNewLabel_1.setBounds(416, 61, 237, 14);
		frame.getContentPane().add(lblNewLabel_1);

		JLabel lblTheName = new JLabel("- The name :");
		lblTheName.setFont(new Font("Sitka Subheading", Font.BOLD, 12));
		lblTheName.setBounds(446, 108, 86, 14);
		frame.getContentPane().add(lblTheName);

		nameRecord = new JTextField();
		nameRecord.setBounds(543, 100, 86, 28);
		frame.getContentPane().add(nameRecord);
		nameRecord.setColumns(10);

		JButton btnAdd_1 = new JButton("Add");
		btnAdd_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addFrqRecord();

			}
		});
		btnAdd_1.setFont(new Font("Sitka Subheading", Font.BOLD, 13));
		btnAdd_1.setBounds(480, 232, 76, 23);
		frame.getContentPane().add(btnAdd_1);

		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				updateFrqRecord();

			}
		});
		btnUpdate.setFont(new Font("Sitka Subheading", Font.BOLD, 12));
		btnUpdate.setBounds(570, 232, 76, 23);
		frame.getContentPane().add(btnUpdate);

		JLabel lblNewFreq = new JLabel("- New freq :");
		lblNewFreq.setFont(new Font("Sitka Subheading", Font.BOLD, 13));
		lblNewFreq.setBounds(446, 146, 86, 14);
		frame.getContentPane().add(lblNewFreq);

		JLabel lblNewYear = new JLabel("- New year :");
		lblNewYear.setFont(new Font("Sitka Subheading", Font.BOLD, 13));
		lblNewYear.setBounds(446, 180, 86, 14);
		frame.getContentPane().add(lblNewYear);

		freqRecord = new JTextField();
		freqRecord.setColumns(10);
		freqRecord.setBounds(543, 143, 86, 28);
		frame.getContentPane().add(freqRecord);

		yearRecord = new JTextField();
		yearRecord.setColumns(10);
		yearRecord.setBounds(543, 180, 86, 28);
		frame.getContentPane().add(yearRecord);
		frame.setBounds(100, 100, 788, 418);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void search() {

	}

	public void median() {

	}

	public void delete() {

	}

	public void addNameRecord() {

	}

	public void maxName() {

	}

	public void addFrqRecord() {

	}

	public void updateFrqRecord() {

	}
}
